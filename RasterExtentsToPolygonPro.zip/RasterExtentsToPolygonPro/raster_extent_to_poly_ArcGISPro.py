try:
    import sys
    import traceback
    import os
    import arcpy
    arcpy.AddMessage("Another Lummi GIS geoprocessing tool by Gerry Gabrisch, GISP - 1/25/2023  geraldg@lummi-nsn.gov...")

    
    inDir = arcpy.GetParameterAsText(0)
    outFile = arcpy.GetParameterAsText(1)
    
    ##For the IDE folks uncode here.
    #inDir = r'E:\WAWHAT22-MOSAICS-LIB\Ortho Mosaic Tiles\WAWHAT22-GEO-TILES-3INCH'
    #outFile = r'E:\WAWHAT22-MOSAICS-LIB\Ortho Mosaic Tiles\raterExtents3inch.shp'
    
    feature_classes = []
    
    arcpy.AddMessage("Fetching raster list...")
    walk = arcpy.da.Walk(inDir, datatype="RasterDataset", type="All")
    
    for dirpath, dirnames, filenames in walk:
        for filename in filenames:
            feature_classes.append(os.path.join(dirpath, filename))
    arcpy.AddMessage("Creating polygon featureclass...")
    arcpy.management.CreateFeatureclass(os.path.dirname(outFile),os.path.basename(outFile),"POLYGON")
    
    arcpy.AddMessage("Building  fields...")
    arcpy.management.AddField(outFile,"RasterName", "String","","",100)
    arcpy.management.AddField(outFile,"RasterPath", "String","","",250)
    
    
    
    cursor = arcpy.InsertCursor(outFile)
    point = arcpy.Point()
    array = arcpy.Array()
    corners = ["lowerLeft", "lowerRight", "upperRight", "upperLeft"]
    
    arcpy.AddMessage("Populating fields. Hold on!...")
   
    for Ras in feature_classes:
        feat = cursor.newRow()  
        r = arcpy.Raster(Ras)
        for corner in corners:    
            point.X = getattr(r.extent, "%s" % corner).X
            point.Y = getattr(r.extent, "%s" % corner).Y
            array.add(point)
        array.add(array.getObject(0))
        polygon = arcpy.Polygon(array)
        feat.shape = polygon
        feat.setValue("RasterName", Ras.split('\\')[-1])
        feat.setValue("RasterPath", Ras)
        cursor.insertRow(feat)
        array.removeAll()
    del feat
    del cursor  
    
    
    arcpy.AddMessage("Finished without error :)")
    arcpy.AddMessage("Thanks for using Raster Extents to Polygon for ArcGIS Pro.")
    
    
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    print ("PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1]))